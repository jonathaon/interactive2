// $(document).ready(function(){

//     console.log('hi');

// 	// $(document).keypress(function(e) {
// 	//     $('#A').append(String.fromCharCode(e.which));
// 	//     // the keycode for 'a' is 97
// 	//     if ( e.which == 97 ) {
// 	//         $('#A').addClass('special');
// 	//     }

// 	// });

// });

$(document).ready(function(){
	
	console.log('hi');

});